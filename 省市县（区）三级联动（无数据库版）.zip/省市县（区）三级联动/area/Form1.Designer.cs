﻿namespace area
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.cbotown = new System.Windows.Forms.ComboBox();
            this.cbocity = new System.Windows.Forms.ComboBox();
            this.cboprovince = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // cbotown
            // 
            this.cbotown.FormattingEnabled = true;
            this.cbotown.Location = new System.Drawing.Point(290, 87);
            this.cbotown.Name = "cbotown";
            this.cbotown.Size = new System.Drawing.Size(121, 20);
            this.cbotown.TabIndex = 12;
            this.cbotown.Text = "请选择";
            // 
            // cbocity
            // 
            this.cbocity.FormattingEnabled = true;
            this.cbocity.Location = new System.Drawing.Point(290, 61);
            this.cbocity.Name = "cbocity";
            this.cbocity.Size = new System.Drawing.Size(121, 20);
            this.cbocity.TabIndex = 11;
            this.cbocity.Text = "请选择";
            this.cbocity.SelectedIndexChanged += new System.EventHandler(this.cbocity_SelectedIndexChanged);
            // 
            // cboprovince
            // 
            this.cboprovince.FormattingEnabled = true;
            this.cboprovince.Location = new System.Drawing.Point(290, 35);
            this.cboprovince.Name = "cboprovince";
            this.cboprovince.Size = new System.Drawing.Size(121, 20);
            this.cboprovince.TabIndex = 10;
            this.cboprovince.Text = "请选择省份";
            this.cboprovince.SelectedIndexChanged += new System.EventHandler(this.cboprovince_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(651, 266);
            this.Controls.Add(this.cbotown);
            this.Controls.Add(this.cbocity);
            this.Controls.Add(this.cboprovince);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox cbotown;
        private System.Windows.Forms.ComboBox cbocity;
        private System.Windows.Forms.ComboBox cboprovince;
    }
}

